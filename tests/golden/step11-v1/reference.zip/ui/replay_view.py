"""Detached sampled-state viewer; never calls live map/drone/swarm methods."""
import pygame
from core.replay import decode_bits
from core.utils import draw_text, get_font


def draw_replay(screen, player, paused=False):
    screen.fill((10,12,20))
    world=player.world;state=player.current;cfg=player.configuration
    rows,cols=world['rows'],world['cols']
    scale=min((screen.get_width()-30)/cols,(screen.get_height()-105)/rows)
    fog=decode_bits(state['fog'],rows,cols)
    colors=((18,28,45),(60,65,80),(120,30,30),(140,60,10),(20,60,110),(20,100,60))
    for row in range(rows):
        for col in range(cols):
            color=colors[world['grid'][row][col]] if fog[row,col] else (8,10,18)
            pygame.draw.rect(screen,color,(15+col*scale,80+row*scale,scale+1,scale+1))
    def point(px,py):return (int(15+px/cfg['CELL_SIZE']*scale),int(80+py/cfg['CELL_SIZE']*scale))
    for idx,z in enumerate(world['survivors']):
        if fog[z['row'],z['col']]:
            pygame.draw.circle(screen,(0,255,100) if idx in state['found'] else (255,200,0),
                               point((z['col']+.5)*cfg['CELL_SIZE'],(z['row']+.5)*cfg['CELL_SIZE']),5,1)
    pygame.draw.circle(screen,(255,210,50),point((cfg['BASE_COL']+.5)*cfg['CELL_SIZE'],(cfg['BASE_ROW']+.5)*cfg['CELL_SIZE']),7,2)
    for d in state['drones']:
        color=(220,70,70) if d['state'] in ('failed','stranded') else (0,220,180)
        pygame.draw.circle(screen,color,point(d['px'],d['py']),4)
        x,y=point(d['px'],d['py'])
        draw_text(screen,f"D{d['id']} {d['state']} {100*d['bat']/d['battery_max']:.0f}%",x+6,y,get_font(11),color)
    status='paused' if paused and player.status!='completed' else player.status
    draw_text(screen,f"REPLAY {status.upper()} | seed {player.seed} | playhead {player.tick}/{player.end_tick} | {player.tick/60:.2f}s",
              15,10,get_font(16),(200,210,230))
    draw_text(screen,f"Snapshot tick {state['frame']} (held between samples) | {state['weather']} | survivors {len(state['found'])}/{len(world['survivors'])}",
              15,33,get_font(13),(200,210,230))
    extent=f"Recorded prefix ends at {player.end_tick}; exported at {player.export_tick}. " if player.export_tick>player.end_tick else ''
    draw_text(screen,extent+"P pause | R new mission | L reload | no live resume",15,54,get_font(13),(160,170,190))
