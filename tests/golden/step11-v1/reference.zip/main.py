"""
main.py - Autonomous Drone Swarm Simulator
==========================================

Entry point.  Run with:

    python main.py

Controls
--------
  H        Toggle heatmap overlay
  C        Toggle communication links
  S        Toggle sensor rings
  T        Toggle drone trails
  F        Toggle assigned frontier overlay
  V        Toggle reservation-table overlay
  D        Toggle drone decision labels
  P        Pause / resume
  + / -    Camera zoom
  Arrows   Camera pan
  SPACE    Follow next drone
  E        Export replay JSON
  L        Load latest replay JSON
  Y        Rescue stranded drones to base
  R        Restart simulation
  ESC      Quit
  Mouse    Click map to inspect cell (debug)
"""

import math
import sys
import random
import pygame

import config
from core.map import Map
from core.swarm import Swarm
from core.mission import Mission, MISSION_COMPLETE
from core.simulation import make_simulation
from core.utils import world_to_screen, get_font, draw_text, draw_rounded_rect, pulse, lerp_color, clamp
from ui.dashboard import Dashboard
from ui.minimap import Minimap
from ui.replay_view import draw_replay
# Compatibility exports; rendering implementation belongs to presentation.
from ui.presentation import (
    Particle,
    Camera,
    draw_menu_screen,
    draw_pause_screen,
    draw_end_screen,
    draw_settings_screen,
    draw_color_legend,
    draw_weather_overlay,
    draw_mission_complete_screen,
    draw_swarm_debug_overlay,
    draw_comm_graph_overlay,
    draw_docking_debug_line,
    draw_lost_comm_debug_line,
    render_simulation_frame,
)


APP_MENU = "menu"
APP_RUNNING = "running"
APP_PAUSED = "paused"
APP_SETTINGS = "settings"
APP_END = "end"


def is_mission_failed(swarm, mission) -> bool:
    # FAILED drones recover and STRANDED drones allow operator rescue. ADSS has
    # no irreversible failure/time-limit policy; blockage is not an outcome.
    return False


# ──────────────────────────────────────────────
# Main loop
# ──────────────────────────────────────────────

def main():
    pygame.init()
    pygame.display.set_caption(config.WINDOW_TITLE)
    screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
    clock  = pygame.time.Clock()

    # ── Init simulation ──────────────────────
    game_map, swarm, mission, seed = make_simulation()
    dashboard = Dashboard()
    minimap   = Minimap()

    # ── Render surfaces ──────────────────────
    # Map surface (world-space, offset to screen via MAP_OFFSET_*)
    map_surf = pygame.Surface((config.MAP_PIXEL_W, config.MAP_PIXEL_H))

    # ── State flags ──────────────────────────
    show_heatmap = False
    show_comm    = True
    show_sensor  = True
    show_trail   = True
    show_frontiers = False
    show_reservations = False
    show_decisions = False

    frame        = 0
    fps_display  = 60
    fps_timer    = 0

    particles: list[Particle] = []
    prev_found   = set()

    # ──────────────────────────────────────────
    # Game loop
    # ──────────────────────────────────────────
    running = True
    while running:

        # ── Events ──────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_r:
                    game_map, swarm, mission, seed = make_simulation()
                    dashboard = Dashboard()
                    minimap   = Minimap()
                    particles.clear()
                    prev_found.clear()
                    frame = 0
                elif event.key == pygame.K_h:
                    show_heatmap = not show_heatmap
                elif event.key == pygame.K_c:
                    show_comm = not show_comm
                elif event.key == pygame.K_s:
                    show_sensor = not show_sensor
                elif event.key == pygame.K_t:
                    show_trail = not show_trail
                elif event.key == pygame.K_f:
                    show_frontiers = not show_frontiers
                elif event.key == pygame.K_v:
                    show_reservations = not show_reservations
                elif event.key == pygame.K_d:
                    show_decisions = not show_decisions
                elif event.key == pygame.K_y:
                    if not mission.replay_playback_active:
                        swarm.rescue_stranded_to_base()
                elif event.key == pygame.K_e:
                    try:
                        mission.export_replay()
                    except Exception as exc:
                        swarm.alerts.append(f"Replay export failed: {exc}")
                elif event.key == pygame.K_l:
                    try:
                        mission.load_last_replay()
                    except Exception as exc:
                        swarm.alerts.append(f"Replay load failed: {exc}")

        if mission.replay_playback_active:
            mission.update()
            draw_replay(screen, mission.replay_player)
            pygame.display.flip()
            clock.tick(config.TARGET_FPS)
            frame += 1
            continue

        # ── Simulation step ──────────────────────
        if mission.state != MISSION_COMPLETE:
            mission.update()

        # Collect alerts for dashboard
        dashboard.add_alerts(swarm.active_alerts())

        # Spawn particles on mission discovery
        new_found = game_map.mission_found - prev_found
        for mz_idx in new_found:
            mz = game_map.mission_zones[mz_idx]
            bx, by = game_map.cell_to_pixel(mz.col, mz.row)
            for _ in range(40):
                particles.append(Particle(
                    bx + config.MAP_OFFSET_X,
                    by + config.MAP_OFFSET_Y))
        prev_found = set(game_map.mission_found)

        # Update particles
        particles = [p for p in particles if p.life > 0]
        for p in particles:
            p.update()

        # FPS measurement
        fps_timer += 1
        if fps_timer >= 20:
            fps_timer   = 0
            fps_display = int(clock.get_fps())

        # ── Render ──────────────────────────────
        screen.fill(config.C_BG)

        # 1. Map background (tile surface with fog-of-war)
        tile_surf = game_map.get_tile_surface()
        map_surf.blit(tile_surf, (0, 0))

        # 2. Heatmap overlay
        if show_heatmap:
            game_map.draw_heatmap_overlay(map_surf)

        # 3. Mission zones
        game_map.draw_mission_zones(map_surf)

        # 4. Base station
        game_map.draw_base(map_surf)

        draw_swarm_debug_overlay(
            map_surf, swarm,
            show_frontiers=show_frontiers,
            show_reservations=show_reservations,
            show_decisions=False,
        )

        # 5. Communication links (drone-to-drone)
        if show_comm:
            comm_surf = pygame.Surface((config.MAP_PIXEL_W, config.MAP_PIXEL_H), pygame.SRCALPHA)
            for drone in swarm.drones:
                drone.draw_comm_links(comm_surf, swarm.drones)
            draw_comm_graph_overlay(comm_surf, swarm)
            map_surf.blit(comm_surf, (0, 0))

        # 6. Drones
        for drone in swarm.drones:
            drone.draw(map_surf, show_sensor=show_sensor, show_trail=show_trail,
                       show_comm=show_comm)

        # 7. Drone ID labels
        font_sm = get_font(config.FONT_MONO_SM)
        for drone in swarm.drones:
            lx = int(drone.px) + config.DRONE_RADIUS + 2
            ly = int(drone.py) - config.DRONE_RADIUS - 1
            draw_text(map_surf, f"D{drone.drone_id}", lx, ly, font_sm, (220, 220, 255))

        if show_decisions:
            draw_swarm_debug_overlay(
                map_surf, swarm,
                show_frontiers=False,
                show_reservations=False,
                show_decisions=True,
            )

        # 8. Blit map_surf to screen with offset
        screen.blit(map_surf, (config.MAP_OFFSET_X, config.MAP_OFFSET_Y))

        # 9. Map border
        pygame.draw.rect(screen, config.C_UI_BORDER,
                         (config.MAP_OFFSET_X, config.MAP_OFFSET_Y,
                          config.MAP_PIXEL_W, config.MAP_PIXEL_H), 1)

        # 10. Weather effects
        draw_weather_overlay(screen, mission.weather.current, frame)

        # 11. Particles
        for p in particles:
            p.draw(screen)

        # 12. Minimap (title-bar area, above map)
        minimap.draw(screen, game_map, swarm.drones, frame)

        # 13. Top title bar info (right side of minimap)
        font_title = get_font(config.FONT_TITLE, bold=True)
        font_md    = get_font(config.FONT_MONO_MD)
        title_x = config.MAP_OFFSET_X + 180
        draw_text(screen, "AUTONOMOUS DRONE SWARM SIMULATOR",
                  title_x, 8, font_title, config.C_UI_ACCENT)
        draw_text(screen, f"Seed: {seed}   Drones: {config.NUM_DRONES}   "
                          f"Map: {config.MAP_COLS}×{config.MAP_ROWS}",
                  title_x, 28, font_md, config.C_UI_TEXT)

        draw_text(screen, f"[F]Frontiers {'ON' if show_frontiers else 'OFF'}  "
                          f"[V]Reservations {'ON' if show_reservations else 'OFF'}  "
                          f"[D]Decisions {'ON' if show_decisions else 'OFF'}  [Y]Rescue [E]Export [L]Load",
                  title_x + 420, 28, font_md, config.C_UI_BORDER)
        draw_docking_debug_line(screen, swarm)
        draw_lost_comm_debug_line(screen, swarm)

        # 14. Dashboard panel (right side)
        dashboard.draw(screen, swarm, mission, fps_display, frame,
                       show_heatmap, show_comm)

        # 15. Mission complete overlay
        if mission.state == MISSION_COMPLETE:
            draw_mission_complete_screen(screen, mission, frame)

        pygame.display.flip()
        clock.tick(config.TARGET_FPS)
        frame += 1

    pygame.quit()
    sys.exit(0)


def run_app():
    pygame.init()
    pygame.display.set_caption(config.WINDOW_TITLE)
    screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
    clock = pygame.time.Clock()

    game_map, swarm, mission, seed = make_simulation()
    dashboard = Dashboard()
    minimap = Minimap()
    map_surf = pygame.Surface((config.MAP_PIXEL_W, config.MAP_PIXEL_H))
    camera = Camera()
    flags = {
        "show_heatmap": False,
        "show_comm": True,
        "show_sensor": True,
        "show_trail": True,
        "show_frontiers": False,
        "show_reservations": False,
        "show_decisions": False,
    }
    frame = 0
    fps_display = 60
    fps_timer = 0
    particles: list[Particle] = []
    prev_found = set()
    app_state = APP_MENU
    menu_selected = 0
    settings_selected = 0
    demo_mode = False
    mission_failed = False

    def reset_simulation(cinematic: bool = False):
        nonlocal game_map, swarm, mission, seed, dashboard, minimap
        nonlocal particles, prev_found, frame, demo_mode, mission_failed
        game_map, swarm, mission, seed = make_simulation()
        dashboard = Dashboard()
        minimap = Minimap()
        particles = []
        prev_found = set()
        frame = 0
        demo_mode = cinematic
        mission_failed = False
        camera.reset()
        if cinematic:
            camera.set_zoom(1.25)
            flags.update({
                "show_comm": True,
                "show_sensor": True,
                "show_trail": True,
                "show_frontiers": True,
                "show_reservations": False,
                "show_decisions": False,
            })

    def handle_menu_action(label: str) -> bool:
        nonlocal app_state, demo_mode
        if label == "Start Mission":
            reset_simulation(False)
            app_state = APP_RUNNING
        elif label == "Demo Mode":
            reset_simulation(True)
            app_state = APP_RUNNING
        elif label == "Replay Viewer":
            reset_simulation(False)
            demo_mode = False
            try:
                mission.load_last_replay()
                camera.set_zoom(1.05)
            except Exception as exc:
                swarm.alerts.append(f"Replay load failed: {exc}")
                app_state = APP_MENU
                return True
            app_state = APP_RUNNING
        elif label == "Settings":
            app_state = APP_SETTINGS
        elif label == "Quit":
            return False
        return True

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                continue
            if event.type == pygame.MOUSEWHEEL and app_state in (APP_RUNNING, APP_PAUSED, APP_END):
                camera.zoom_by(0.12 * event.y)
                continue
            if event.type == pygame.MOUSEBUTTONDOWN and app_state == APP_MENU:
                for label, rect in draw_menu_screen(screen, menu_selected, frame):
                    if rect.collidepoint(event.pos):
                        running = handle_menu_action(label)
                        break
                continue
            if event.type != pygame.KEYDOWN:
                continue

            if app_state == APP_MENU:
                labels = ["Start Mission", "Demo Mode", "Replay Viewer", "Settings", "Quit"]
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    menu_selected = (menu_selected + 1) % len(labels)
                elif event.key in (pygame.K_UP, pygame.K_w):
                    menu_selected = (menu_selected - 1) % len(labels)
                elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    running = handle_menu_action(labels[menu_selected])
                elif pygame.K_1 <= event.key <= pygame.K_5:
                    running = handle_menu_action(labels[event.key - pygame.K_1])
                continue

            if app_state == APP_SETTINGS:
                keys = list(flags.keys())
                if event.key == pygame.K_ESCAPE:
                    app_state = APP_MENU
                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    settings_selected = (settings_selected + 1) % len(keys)
                elif event.key in (pygame.K_UP, pygame.K_w):
                    settings_selected = (settings_selected - 1) % len(keys)
                elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    flags[keys[settings_selected]] = not flags[keys[settings_selected]]
                elif pygame.K_1 <= event.key <= pygame.K_7:
                    idx = event.key - pygame.K_1
                    if idx < len(keys):
                        flags[keys[idx]] = not flags[keys[idx]]
                elif event.key in (pygame.K_EQUALS, pygame.K_PLUS):
                    camera.zoom_by(0.15)
                elif event.key in (pygame.K_MINUS, pygame.K_UNDERSCORE):
                    camera.zoom_by(-0.15)
                continue

            if event.key == pygame.K_ESCAPE:
                app_state = APP_PAUSED if app_state == APP_RUNNING else APP_MENU
            elif event.key == pygame.K_p:
                app_state = APP_PAUSED if app_state == APP_RUNNING else APP_RUNNING
            elif event.key == pygame.K_m:
                app_state = APP_MENU
            elif event.key == pygame.K_r:
                reset_simulation(demo_mode)
                app_state = APP_RUNNING
            elif event.key in (pygame.K_EQUALS, pygame.K_PLUS):
                camera.zoom_by(0.15)
            elif event.key in (pygame.K_MINUS, pygame.K_UNDERSCORE):
                camera.zoom_by(-0.15)
            elif event.key == pygame.K_SPACE:
                camera.follow_next(swarm.drones)
            elif event.key == pygame.K_q:
                camera.follow_id = None
                camera.set_zoom(1.0)
            elif event.key == pygame.K_h:
                flags["show_heatmap"] = not flags["show_heatmap"]
            elif event.key == pygame.K_c:
                flags["show_comm"] = not flags["show_comm"]
            elif event.key == pygame.K_s:
                flags["show_sensor"] = not flags["show_sensor"]
            elif event.key == pygame.K_t:
                flags["show_trail"] = not flags["show_trail"]
            elif event.key == pygame.K_f:
                flags["show_frontiers"] = not flags["show_frontiers"]
            elif event.key == pygame.K_v:
                flags["show_reservations"] = not flags["show_reservations"]
            elif event.key == pygame.K_d:
                flags["show_decisions"] = not flags["show_decisions"]
            elif event.key == pygame.K_y:
                if not mission.replay_playback_active:
                    swarm.rescue_stranded_to_base()
            elif event.key == pygame.K_e:
                try:
                    mission.export_replay()
                except Exception as exc:
                    swarm.alerts.append(f"Replay export failed: {exc}")
            elif event.key == pygame.K_l:
                try:
                    mission.load_last_replay()
                except Exception as exc:
                    swarm.alerts.append(f"Replay load failed: {exc}")

        if app_state == APP_MENU:
            draw_menu_screen(screen, menu_selected, frame)
            pygame.display.flip()
            clock.tick(config.TARGET_FPS)
            frame += 1
            continue
        if app_state == APP_SETTINGS:
            draw_settings_screen(screen, settings_selected, flags, camera, frame)
            pygame.display.flip()
            clock.tick(config.TARGET_FPS)
            frame += 1
            continue

        if mission.replay_playback_active:
            if app_state == APP_RUNNING:
                mission.update()
            draw_replay(screen, mission.replay_player, app_state != APP_RUNNING)
            pygame.display.flip()
            clock.tick(config.TARGET_FPS)
            frame += 1
            continue

        if app_state == APP_RUNNING and mission.state != MISSION_COMPLETE and not mission_failed:
            mission.update()
            mission_failed = is_mission_failed(swarm, mission)
            if mission_failed or mission.state == MISSION_COMPLETE:
                app_state = APP_END

        if demo_mode and app_state == APP_RUNNING:
            flags["show_comm"] = True
            flags["show_trail"] = True
            flags["show_sensor"] = frame % 900 < 690
            flags["show_frontiers"] = frame % 960 < 300
            flags["show_reservations"] = frame % 1500 < 240
            active = [d for d in swarm.drones if d.state in ("scanning", "lost_comm", "returning")]
            if active and frame % 420 == 0:
                camera.follow_drone(random.choice(active).drone_id, 1.45)
            if mission.replay_playback_active:
                camera.set_zoom(1.15)

        keys = pygame.key.get_pressed() if app_state in (APP_RUNNING, APP_PAUSED, APP_END) else None
        camera.update(swarm.drones, keys)
        dashboard.add_alerts(swarm.active_alerts())

        new_found = game_map.mission_found - prev_found
        for mz_idx in new_found:
            mz = game_map.mission_zones[mz_idx]
            bx, by = game_map.cell_to_pixel(mz.col, mz.row)
            for _ in range(70):
                particles.append(Particle(bx, by))
            finder = next((d.drone_id for d in swarm.drones if mz_idx in d.mission_found), 0)
            camera.follow_drone(finder, 1.65)
        prev_found = set(game_map.mission_found)

        particles = [p for p in particles if p.life > 0]
        for p in particles:
            p.update()

        fps_timer += 1
        if fps_timer >= 20:
            fps_timer = 0
            fps_display = int(clock.get_fps())

        render_simulation_frame(screen, map_surf, camera, game_map, swarm, mission,
                                dashboard, minimap, particles, flags, fps_display,
                                frame, seed, demo_mode)
        if app_state == APP_PAUSED:
            draw_pause_screen(screen, mission, swarm, frame, demo_mode)
        elif app_state == APP_END:
            draw_end_screen(screen, mission, swarm, frame, mission_failed)

        pygame.display.flip()
        clock.tick(config.TARGET_FPS)
        frame += 1

    pygame.quit()
    sys.exit(0)


if __name__ == "__main__":
    run_app()
